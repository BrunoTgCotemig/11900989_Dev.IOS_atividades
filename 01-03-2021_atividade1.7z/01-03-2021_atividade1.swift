4copyPaste: fileName = 01-03-2021_atividade1.swift
-- colocar o email no professor no github
-- entragar o link

DevMobile: IOS




Atividade 1º



Por:

Bruno Teles Galvao;
3b1; n º 10;










=================
Questão 1 - 
Da forma mais longa para a mais curta maneira de escrever, declare variáveis
em um código Swift.

Resposta:
```
 var _1: String = "Marilene Suprema e imortal";
 
 var _1 = 0


```
=================




=================
Questão 2 -
Ao pensar em um sistema de venda de carros, ao cadastrar um novo para
venda pense em quais informações seriam constantes e quais seriam variáveis, e
declare esses dados em um código Swift.

Resposta:
 ```
 
 let codico_geral_do_produto:Int = 102092
 let nome_publico:String = "Honda Fit 2021"
 
 let tracao: String = "Diantera"
 
 var valor: Float = 92000.00
 
 var estepe_temporareo: Bool =  true
 
 ```
=================




=================
Questão 3 - 
Descreva seu entendimento sobre anotação de tipos no Swift.

Resposta:
 
O swift é uma linguagem flexível no cerne ao uso tipos em variáveis. Ela conta com funcionalidades
"type safety" e "type inference" dispondo de maior conforto e mais ferrametas para aqueles que nela programam:
é possivel escolher fazer o uso dos 'tipos' para uma programação mais segura, ou não, para um códico com
maior demazelo.
 
=================




=================
Questão 4 - 
Declare uma variável do tipo Int e outra do tipo Double, e converta as duas para
um texto do tipo String em uma terceira variável.

Resposta:
```


var _1: Int = 1; var _2: Float = 1.123;

var _3: String = String(_1) + " - " + String(_2);
print(_3);



``` 
=================



=================
Questão 5 - 
Defina os conceitos de Type Safety e Type Inference.

Resposta:

Quando uma linguagem de programação é considerada como "Type Safety" indica que ela possue
a habilidade de determinar um tipo fixo para uma variavel, que não pode ser alterado; em  "type inference"
não é necessario determinar o tipo da variável, tornando-as flexiveis, aceitando qualquer tipo de 
informação.
 
=================